#include "gestErrores.h"

//Tamaño del buffer
#define TAM 256

////FUNCIONES////
void load();
char sigCaracter();
void retroceder();
void igualar();
char* obtenerLexema();
void close();
void cargaMemorias();
void cambiaMemorias();
int finalFichero();




