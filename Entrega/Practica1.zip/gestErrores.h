////TIPOS////
#define FICHERO 1
#define LEXEMA 2
#define CARACTER 3

////FUNCIONES////
void error(int error);
void mostrar(char* mensaje);
