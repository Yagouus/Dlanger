//PALABRAS RESERVADAS
#define IMPORT 300
#define WHILE 301
#define FOREACH 302
#define RETURN 303
#define CAST 304
#define DOUBLE 305
#define INT 306
#define VOID 307

//Operadores
#define MASIGUAL 310
#define MASMAS 311
#define IGUALIGUAL 312

//Identificadores
#define ID 320

//Tipos de dato
#define T_INTEGER 330
#define T_FLOAT 331
#define T_BINARIO 332
#define T_NCIENTIFICA 333
#define T_CADENA 334


